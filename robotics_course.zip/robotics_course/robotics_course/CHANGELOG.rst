^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package robotics_course
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.2 (2021-10-29)
------------------
* change from smb (eth zurich) to mrob platform
* update catkin minimum requirement
* update dependencies mrob_gazebo to include pointcloud_to_laserscan
* Contributors: Kerui, Elvis Dowson, Will Son


